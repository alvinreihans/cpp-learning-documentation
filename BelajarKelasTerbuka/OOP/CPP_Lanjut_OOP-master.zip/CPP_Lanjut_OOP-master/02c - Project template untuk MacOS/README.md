## Template untuk tutorial OOP di MacOS

# Software yang dibutuhkan
1. Text Editor: Visual Studio Code 
   Download di: https://code.visualstudio.com/docs/?dv=osx

2. Compiler:
    Download XCode di app store, atau ikuti instruksi disini https://www.ics.uci.edu/~pattis/common/handouts/macclion/clang.html

3. Extensions untuk VSC:
    - C/C++
    - themes: Atom One Dark (optional)
    - Icon: vscode-icons (optional)