class DummyClass{
    public:
        int data;

        DummyClass(const int &value);
        void setData(const int &value);
        int getData();
        void print();
};