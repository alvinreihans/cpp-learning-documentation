#include <iostream>

using namespace std;

int main(int argc, char const *argv[])
{
    cout << "hello world" << endl;
    cout << "instalasi berhasil" << endl;
    return 0;
}
